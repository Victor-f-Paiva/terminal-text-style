from terminal_text_style import style as s

print(s.color_text(back='yellow', message='Abacaxi com goiaba'))
print(s.color_text(text='red', message='Abacaxi com goiaba'))
